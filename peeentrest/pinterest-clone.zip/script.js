document.addEventListener('DOMContentLoaded', () => {
  const board = document.getElementById('board');
  const uploadForm = document.getElementById('uploadForm');
  const imageInput = document.getElementById('imageInput');
  const descriptionInput = document.getElementById('descriptionInput');
  const exportSelectedBtn = document.getElementById('exportSelectedBtn');
  const batchExportBtn = document.getElementById('batchExportBtn');
  const importZipInput = document.getElementById('importZipInput');

  const STORAGE_KEY = 'pinterestCloneBoard';

  let cardsData = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];

  // Render cards on the board with checkboxes
  function renderBoard() {
    board.innerHTML = '';
    cardsData.forEach((card, index) => {
      const cardEl = createCardElement(card, index);
      board.appendChild(cardEl);
    });
    addDragAndDropListeners();
  }

  // Create a card element with checkbox
  function createCardElement(card, index) {
    const cardDiv = document.createElement('div');
    cardDiv.className = 'bg-white rounded-lg shadow-md overflow-hidden cursor-move relative';
    cardDiv.setAttribute('draggable', 'true');
    cardDiv.dataset.index = index;

    // Checkbox for selection
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'absolute top-2 left-2 w-5 h-5 z-10';
    checkbox.dataset.index = index;

    const img = document.createElement('img');
    img.src = card.image;
    img.alt = card.description;
    img.className = 'w-full h-48 object-cover';

    const desc = document.createElement('p');
    desc.textContent = card.description;
    desc.className = 'p-3 text-gray-700 text-sm';

    cardDiv.appendChild(checkbox);
    cardDiv.appendChild(img);
    cardDiv.appendChild(desc);

    return cardDiv;
  }

  function saveToStorage() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cardsData));
  }

  uploadForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const file = imageInput.files[0];
    const description = descriptionInput.value.trim();
    if (!file || !description) return;

    const reader = new FileReader();
    reader.onload = function(event) {
      const base64Image = event.target.result;
      cardsData.push({ image: base64Image, description });
      saveToStorage();
      renderBoard();
      uploadForm.reset();
    };
    reader.readAsDataURL(file);
  });

  // Drag and Drop handlers
  let dragSrcEl = null;text/html', this.outerHTML);
    this.classList.add('opacity-50');
  }

  function handleDragOver(e) {
    if (e.preventDefault) e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    return false;
  }

  function handleDragEnter() {
    this.classList.add('border-4', 'border-pink-600');
  }

  function handleDragLeave() {
    this.classList.remove('border-4', 'border-pink-600');
  }

  function handleDrop(e) {
    if (e.stopPropagation) e.stopPropagation();
    if (dragSrcEl !== this) {
      const fromIndex = parseInt(dragSrcEl.dataset.index);
      const toIndex = parseInt(this.dataset.index);
      const movedItem = cardsData.splice(fromIndex, 1)[0];
      cardsData.splice(toIndex, 0, movedItem);
      saveToStorage();
      renderBoard();
    }
    return false;
  }

  function handleDragEnd() {
    this.classList.remove('opacity-50');
    const cards = board.querySelectorAll('div[draggable="true"]');
    cards.forEach(card => card.classList.remove('border-4', 'border-pink-600'));
  }

  function addDragAndDropListeners() {
    const cards = board.querySelectorAll('div[draggable="true"]');
    cards.forEach(card => {
      card.addEventListener('dragstart', handleDragStart);
      card.addEventListener('dragenter', handleDragEnter);
      card.addEventListener('dragover', handleDragOver);
      card.addEventListener('dragleave', handleDragLeave);
      card.addEventListener('drop', handleDrop);
      card.addEventListener('dragend', handleDragEnd);
    });
  }

  // Export selected photos as ZIP
  exportSelectedBtn.addEventListener('click', async () => {
    const selectedIndexes = Array.from(board.querySelectorAll('input[type="checkbox"]:checked')).map(cb => parseInt(cb.dataset.index));
    if (selectedIndexes.length === 0) {
      alert('Please select at least one photo to export.');
      return;
    }
    await exportPhotos(selectedIndexes);
  });

  // Batch export all photos as ZIP
  batchExportBtn.addEventListener('click', async () => {
    if (cardsData.length === 0) {
      alert('No photos to export.');
      return;
    }
    await exportPhotos(cardsData.map((_, idx) => idx));
  });

  // Export photos helper
  async function exportPhotos(indexes) {
    const zip = new JSZip();
    const descLines = [];

    for (const i of indexes) {
      const card = cardsData[i];
      // Extract base64 data
      const base64Data = card.image.split(',')[1];
      const ext = card.image.substring("data:image/".length, card.image.indexOf(";base64"));
      const filename = `photo_${i + 1}.${ext}`;
      zip.file(filename, base64Data, { base64: true });
      descLines.push(`${filename}: ${card.description}`);
    }

  }

  // Import ZIP file and extract photos and descriptions
  importZipInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const zip = new JSZip();
    try {
      const content = await zip.loadAsync(file);
      const newCards = [];

      // Read descriptions.txt if exists
      let descriptions = {};
      if (content.files['descriptions.txt']) {
        const descText = await content.files['descriptions.txt'].async('string');
        descText.split('\n').forEach(line => {
          const [filename, ...descParts] = line.split(':');
          if (filename && descParts.length > 0) {
            descriptions[filename.trim()] = descParts.join(':').trim();
          }
        });
      }

      // Extract images
      for (const filename in content.files) {
        if (filename === 'descriptions.txt') continue;
        const fileData = await content.files[filename].async('base64');
        const ext = filename.split('.').pop().toLowerCase();
        const mimeType = ext === 'png' ? 'image/png' : ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' : 'image/*';
        const base64Image = `data:${mimeType};base64,${fileData}`;
        const description = descriptions[filename] || '';
        newCards.push({ image: base64Image, description });
      }

      cardsData = cardsData.concat(newCards);
      saveToStorage();
      renderBoard();
      importZipInput.value = '';
      alert('Import successful!');
    } catch (err) {
      alert('Failed to import ZIP file. Please ensure it is a valid ZIP with photos and descriptions.');
    }
  });

  // Initial render
  renderBoard();

  // Placeholder for Google Drive export
  const exportGoogleDriveBtn = document.getElementById('exportGoogleDriveBtn');

  // Google API configuration parameters
  const GOOGLE_CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID_HERE';
  const GOOGLE_API_KEY = 'YOUR_GOOGLE_API_KEY_HERE';
  const GOOGLE_DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/drive/v3/rest"];
  const GOOGLE_SCOPES = 'https://www.googleapis.com/auth/drive.file';

  // Load Google API client library
  function loadGoogleApiClient() {
    return new Promise((resolve) => {
      gapi.load('client:auth2', resolve);
    });
  }

  // Initialize Google API client
  async function initGoogleClient() {
    await gapi.client.init({
      apiKey: GOOGLE_API_KEY,
      clientId: GOOGLE_CLIENT_ID,
      discoveryDocs: GOOGLE_DISCOVERY_DOCS,
      scope: GOOGLE_SCOPES,
    });
  }

  // Sign in and export to Google Drive
  async function exportToGoogleDrive() {
    await loadGoogleApiClient();
    await initGoogleClient();

    const GoogleAuth = gapi.auth2.getAuthInstance();
    if (!GoogleAuth.isSignedIn.get()) {
      await GoogleAuth.signIn();
    }

    // TODO: Implement file creation and upload to Google Drive here
    alert('Google Drive export logic to be implemented here.');
  }

  exportGoogleDriveBtn.addEventListener('click', () => {
    exportToGoogleDrive().catch(err => {
      console.error('Google Drive export error:', err);
      alert('Failed to export to Google Drive. Check console for details.');
    });
  });

  // Placeholder for Dropbox export
  const exportDropboxBtn = document.getElementById('exportDropboxBtn');
  exportDropboxBtn.addEventListener('click', () => {
    alert('Dropbox export functionality will be implemented here once API keys are provided.');
  });
});
