# Pinterest Clone with Personalizable Board

## Project Overview
This project is a clone of the Pinterest homepage with added custom features allowing users to upload images from their computer, add descriptions, and organize them on a personal board with drag-and-drop functionality. The UI is designed to be dynamic, seamless, and responsive for both desktop and mobile devices.

## Features
- Pinterest-like homepage UI with navigation bar.
- Image upload with description.
- Personal board displaying uploaded images as draggable cards.
- Drag-and-drop to rearrange cards.
- Persistence of uploaded images, descriptions, and card order using browser localStorage.
- Export selected or batch photos as ZIP files with descriptions.
- Import ZIP files to restore photos and descriptions.
- Responsive design for multiple device types.
- Subtle Mother's Day theme with pastel accents.

## How to Run
1. Clone or download the project files.
2. Serve the project directory using a simple HTTP server. For example, using Python:
   ```
   python3 -m http.server 2442 -d pinterest-clone
   ```
3. Open your browser and navigate to `http://localhost:2442`.
4. Use the upload form to add images with descriptions.
5. Organize your photos on the personal board by dragging and dropping.
6. Use the export buttons to save your photos and descriptions as ZIP files.
7. Use the import control to upload ZIP files and restore your photos.

## How to Use
- **Uploading Photos:** Use the "Upload Image" form to select an image and add a description, then click "Add to Board".
- **Organizing Photos:** Drag and drop photo cards to rearrange their order on your personal board.
- **Selecting Photos:** Use the checkboxes on each photo card to select photos for export.
- **Exporting Photos:**
  - Click "Export Selected" to download a ZIP file of selected photos and their descriptions.
  - Click "Batch Export" to download a ZIP file of all photos and descriptions.
- **Importing Photos:** Click the "Import ZIP" button and select a ZIP file containing photos and descriptions to restore them to your board.

## Data Flow and Persistence

```mermaid
flowchart TD
    User[User Interaction]
    Upload[Upload Image & Description]
    Store[Store Data in localStorage]
    Load[Load Data from localStorage on Page Load]
    Render[Render Personal Board]
    DragDrop[Drag & Drop Cards]
    UpdateStore[Update localStorage on Reorder]
    Export[Export Selected or Batch Photos as ZIP]
    Import[Import ZIP File and Restore Photos]

    User --> Upload --> Store
    Store --> Load --> Render
    User --> DragDrop --> UpdateStore --> Store
    User --> Export
    User --> Import --> Store
```

### Why localStorage?
- localStorage is a simple, built-in browser storage mechanism.
- It allows persistence of data across browser sessions on the same device.
- No backend or server setup is required for this prototype.
- Suitable for storing image metadata and base64 encoded images for small to moderate data sizes.
- Ensures users do not lose their uploaded images and board arrangement.
- Enables quick and seamless user experience without network latency.

## Rooms for Improvement
- Integrate backend storage and user authentication for multi-device sync.
- Support larger file sizes and more efficient image storage (e.g., cloud storage).
- Add user profiles and sharing capabilities.
- Enhance UI customization options and themes.
- Improve accessibility features.
- Add pagination or lazy loading for large photo collections.
- Implement undo/redo functionality for drag-and-drop actions.
- Optimize performance for batch export/import of very large datasets.

---

This README provides detailed instructions and explanations to help users understand, run, and use the Pinterest clone project effectively.
